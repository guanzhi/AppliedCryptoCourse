# 使用说明

## GmSSL3.0编译与安装

GmSSL 3.0 采用了cmake构建系统。下载源代码后将其解压缩，进入源码目录，执行：

```
mkdir build
cd build
cmake ..
make
make test
sudo make install
```

## 应用程序编译与使用

编译命令：

`gcc cr_block.c -L/usr/local/lib -lgmssl -o cr_block`

加密文件示例：

./cr_block -cbc -encrypt -key 0123456789abcdeffedcba9876543210 -iv 0123456789abcdeffedcba9876543210 -in logo.png -out cbc.png

解密文件示例：

./cr_block -cbc -decrypt -key 0123456789abcdeffedcba9876543210 -iv 0123456789abcdeffedcba9876543210 -in cbc.png -out new.png
